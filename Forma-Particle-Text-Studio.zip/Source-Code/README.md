# Forma · Particle Text Studio

A single-page TypeScript and native CSS particle text playground. It uses Canvas 2D to turn text into a field of animated particles with pointer forces, persistent light trails, ambient star dust, layered bloom, five continuous color gradients, bilingual controls, and 4× PNG export.

## Run locally

This project uses Vite to serve and transpile TypeScript in the browser. With Node.js 18 or newer installed, run:

```sh
npx --yes vite --host 127.0.0.1
```

Open the local URL printed by Vite. The first run downloads Vite through `npx`; the page itself uses no runtime JavaScript dependencies. Google Fonts are optional and fall back to system fonts when offline.

## Controls

- Enter text in the left panel; line breaks are preserved. Select a preset to try a phrase.
- Adjust particle size, movement speed, gravity, particle life, and the color palette in real time.
- Move the pointer over the canvas to influence particles. Choose **Attract** or **Repel**, or hold **Shift** to temporarily invert the field.
- Turn motion streaks and bloom on or off independently.
- Select **Export PNG** to save a 4× canvas image.
- Select **简体中文** in the header to switch languages without reloading.

## Type checking

Vite transpiles the TypeScript entry point. For strict, standalone type checking with TypeScript 5, run:

```sh
npx --yes -p typescript tsc --noEmit --strict --target ES2022 --module ESNext --moduleResolution Bundler --lib ES2022,DOM main.ts
```

## Files

- `index.html` — single-page application shell and controls
- `main.ts` — typed Canvas 2D simulation, interaction, localization, and export
- `style.css` — responsive dark UI and native styling
