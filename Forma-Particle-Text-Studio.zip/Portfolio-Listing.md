# Portfolio Listing

## Title

Interactive Particle Text Studio

## Role

Front-End Developer · Independent project

## Description

I made Forma as a small browser experiment with animated type. Enter a phrase and watch the letters break into particles, pull back together, or scatter as you move the pointer.

You can tweak particle size, speed, gravity, lifetime, and color, then turn trails or bloom on and off. It also has English and Simplified Chinese controls and exports a 4× PNG.

Built with TypeScript, Canvas 2D, and plain CSS as an independent project.

## Suggested Skills

- TypeScript
- HTML5
- CSS
- Canvas
- Front-End Development

## Gallery Checklist

Add 2–3 screenshots of the running app before publishing:

1. Full interface with the particle text visible.
2. A close view of the particle effect and pointer interaction.
3. Optional: the Chinese interface or the controls panel.

Use a clean 4:3 crop (1000 × 750 recommended). Do not upload this source folder as the portfolio preview: use screenshots or a public demo URL in Upwork's gallery. The source files here are for reference or later project delivery.

## Project Files

- `index.html` — application page
- `main.ts` — TypeScript Canvas 2D engine and interactions
- `style.css` — application styling
- `README.md` — setup and usage instructions

