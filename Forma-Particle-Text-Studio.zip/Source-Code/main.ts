type Language = "en" | "zh";
type PaletteName = "aurora" | "sunset" | "ice" | "orchid" | "mono";
type Point = { x: number; y: number };
type AmbientStar = Point & { radius: number; alpha: number; phase: number; hue: number };

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetX: number;
  targetY: number;
  radius: number;
  color: string;
  age: number;
  life: number;
  phase: number;
  sparkle: boolean;
};

type Translation = Record<string, string>;

const translations: Record<Language, Translation> = {
  en: {
    brandCaption: "PARTICLE STUDIO", live: "LIVE", export: "Export PNG", eyebrow: "AN INTERACTIVE TYPE EXPERIMENT", headline: "Words in", headlineAccent: "motion.", subtitle: "Turn a thought into a field of light. Shape it, scatter it, make it yours.", note: "A little wonder, in every word.", controlRoom: "THE CONTROL ROOM", yourCanvas: "Your canvas", yourText: "YOUR TEXT", enterToBreak: "↵ ENTER TO BREAK LINES", presetCurious: "CURIOUS", presetDream: "DREAM", presetEnergy: "ENERGY", particlePhysics: "PARTICLE PHYSICS", particleSize: "Particle size", movementSpeed: "Movement speed", gravity: "Gravity", particleLife: "Particle life", colorAtmosphere: "COLOR ATMOSPHERE", colorPalette: "COLOR PALETTE", paletteAurora: "Aurora bloom", paletteSunset: "Solar flare", paletteIce: "Glacier", paletteOrchid: "Orchid haze", paletteMono: "Silver screen", pointerField: "POINTER FIELD", mouseMode: "MOUSE MODE", attract: "Attract", repel: "Repel", motionBlur: "Motion blur", bloom: "Bloom", crafted: "A small universe, made of words.", liveCanvas: "LIVE CANVAS", canvas2d: "CANVAS 2D", interactive: "INTERACTIVE", particleField: "PARTICLE FIELD", dragToExplore: "MOVE TO EXPLORE", particles: "PARTICLES", canvasReady: "CANVAS READY", canvasTip: "Your pointer is part of the composition.", invert: "INVERT FIELD", footerMessage: "MADE OF LIGHT, SHAPED BY YOU", languageTip: "Switch the interface to Simplified Chinese", exportTip: "Save a crisp, 4× PNG of your particle artwork", textTip: "Type a word or phrase; use Enter for a new line", sizeTip: "Adjust each particle's radius", speedTip: "Change how quickly particles find their shape", gravityTip: "Add a gentle downward pull to particle motion", lifeTip: "Set how long each particle glows before renewal", paletteTip: "Choose a color atmosphere for the particle field", attractTip: "Particles drift toward your pointer", repelTip: "Particles scatter away from your pointer", blurTip: "Draw velocity streaks for a sense of motion", bloomTip: "Add a soft, blurred glow behind the particles", emptyText: "Add a word or phrase to start the particle field.", canvasError: "Canvas 2D is unavailable in this browser.", renderError: "The particle field hit a rendering error. Reload the page to try again.", exportError: "The PNG could not be exported. Please try again.", textLimit: "Keep your text to 80 characters or fewer.", exportSuccess: "Your 4× PNG is ready.", textAria: "Text to turn into particles", canvasAria: "Particle text animation", controlsAria: "Controls", stageAria: "Live particle canvas", languageAria: "Switch to Simplified Chinese", interactionAria: "Mouse interaction mode", brandAria: "Forma Particle Studio home", playgroundAria: "Particle text playground", presetsAria: "Text presets"
  },
  zh: {
    brandCaption: "粒子文本工作室", live: "实时运行", export: "导出 PNG", eyebrow: "交互式字体实验", headline: "让文字", headlineAccent: "动起来。", subtitle: "把一个念头变成光的粒子场。塑造它、打散它，让它成为你的作品。", note: "每个词，都藏着一点奇妙。", controlRoom: "创作控制台", yourCanvas: "你的画布", yourText: "输入文字", enterToBreak: "↵ 回车键换行", presetCurious: "好奇", presetDream: "梦想", presetEnergy: "能量", particlePhysics: "粒子物理", particleSize: "粒子大小", movementSpeed: "运动速度", gravity: "重力", particleLife: "粒子寿命", colorAtmosphere: "色彩氛围", colorPalette: "配色方案", paletteAurora: "极光绽放", paletteSunset: "熔金日落", paletteIce: "冰川", paletteOrchid: "兰雾", paletteMono: "银幕", pointerField: "鼠标交互", mouseMode: "鼠标模式", attract: "吸引", repel: "推开", motionBlur: "动态模糊", bloom: "泛光", crafted: "由文字构成的小小宇宙。", liveCanvas: "实时画布", canvas2d: "CANVAS 2D", interactive: "交互已启用", particleField: "粒子场", dragToExplore: "移动鼠标探索", particles: "粒子", canvasReady: "画布已就绪", canvasTip: "你的鼠标也是画面的一部分。", invert: "反转交互", footerMessage: "以光为墨，由你塑形", languageTip: "切换为英文界面", exportTip: "将粒子作品导出为清晰的 4 倍 PNG 图片", textTip: "输入词语或短句，按回车键换行", sizeTip: "调整每个粒子的半径", speedTip: "调整粒子汇聚成形的速度", gravityTip: "为粒子运动添加轻微向下的重力", lifeTip: "设置粒子发光后更新的周期", paletteTip: "为粒子场选择一种色彩氛围", attractTip: "粒子会向鼠标指针靠近", repelTip: "粒子会从鼠标指针处散开", blurTip: "绘制速度拖尾，增强动态感", bloomTip: "在粒子后方增加柔和的模糊辉光", emptyText: "输入一个词语或短句，开始生成粒子。", canvasError: "当前浏览器无法使用 Canvas 2D。", renderError: "粒子场发生渲染错误，请刷新页面重试。", exportError: "无法导出 PNG 图片，请重试。", textLimit: "文字请控制在 80 个字符以内。", exportSuccess: "4 倍高清 PNG 已准备好。", textAria: "转换为粒子的文字", canvasAria: "粒子文字动画", controlsAria: "控制面板", stageAria: "实时粒子画布", languageAria: "切换为英文界面", interactionAria: "鼠标交互模式", brandAria: "Forma 粒子文本工作室首页", playgroundAria: "粒子文本实验区", presetsAria: "文字预设"
  }
};

const palettes: Record<PaletteName, string[]> = {
  aurora: ["#7de7d6", "#70a8ff", "#c7a1ff", "#f1a7d9"],
  sunset: ["#ff875f", "#ffbc71", "#f47c9a", "#c06ef2"],
  ice: ["#baf5ff", "#72d3ef", "#7d9ef5", "#d5e8ff"],
  orchid: ["#f7a9e4", "#be8eff", "#8f8cff", "#ffc7d7"],
  mono: ["#e8f0f6", "#bdc9d8", "#f8fbff", "#96a6b8"]
};

const getElement = <T extends HTMLElement>(id: string): T => {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Missing required element: ${id}`);
  return element as T;
};

const clamp = (value: number, min: number, max: number): number => Math.max(min, Math.min(max, value));

const interpolatePalette = (colors: string[], amount: number): string => {
  const scaled = clamp(amount, 0, 0.9999) * (colors.length - 1);
  const index = Math.floor(scaled);
  const blend = scaled - index;
  const first = Number.parseInt(colors[index].slice(1), 16);
  const second = Number.parseInt(colors[index + 1].slice(1), 16);
  const red = Math.round(((first >> 16) & 255) * (1 - blend) + ((second >> 16) & 255) * blend);
  const green = Math.round(((first >> 8) & 255) * (1 - blend) + ((second >> 8) & 255) * blend);
  const blue = Math.round((first & 255) * (1 - blend) + (second & 255) * blend);
  return `rgb(${red}, ${green}, ${blue})`;
};

const translateDocument = (language: Language): void => {
  document.documentElement.lang = language === "en" ? "en" : "zh-CN";
  document.querySelectorAll<HTMLElement>("[data-i18n]").forEach((element) => {
    const key = element.dataset.i18n;
    if (key) element.textContent = translations[language][key] ?? key;
  });
  document.querySelectorAll<HTMLElement>("[data-tooltip]").forEach((element) => {
    const key = element.dataset.tooltip;
    if (key) element.title = translations[language][key] ?? key;
  });
  document.querySelectorAll<HTMLElement>("[data-i18n-aria]").forEach((element) => {
    const key = element.dataset.i18nAria;
    if (key) element.setAttribute("aria-label", translations[language][key] ?? key);
  });
  const languageButton = document.getElementById("language-toggle");
  if (languageButton) {
    languageButton.textContent = language === "en" ? "简体中文" : "English";
    languageButton.setAttribute("aria-label", translations[language][language === "en" ? "languageAria" : "languageTip"]);
    languageButton.setAttribute("title", translations[language][language === "en" ? "languageTip" : "languageAria"]);
  }
  const textInput = document.getElementById("text-input");
  textInput?.setAttribute("aria-label", translations[language].textAria);
  const canvas = document.getElementById("particle-canvas");
  canvas?.setAttribute("aria-label", translations[language].canvasAria);
  const stage = document.getElementById("stage");
  stage?.setAttribute("aria-label", translations[language].stageAria);
  const controls = document.querySelector(".control-panel");
  controls?.setAttribute("aria-label", translations[language].controlsAria);
  const interaction = document.querySelector(".segmented-control");
  interaction?.setAttribute("aria-label", translations[language].interactionAria);
  document.title = language === "en" ? "Forma — Particle Text Studio" : "Forma — 粒子文本工作室";
};

class ParticleTextApp {
  private readonly canvas = getElement<HTMLCanvasElement>("particle-canvas");
  private readonly stage = getElement<HTMLDivElement>("stage");
  private readonly textInput = getElement<HTMLTextAreaElement>("text-input");
  private readonly notice = getElement<HTMLDivElement>("notice");
  private readonly context: CanvasRenderingContext2D;
  private readonly particleLayer: HTMLCanvasElement;
  private readonly layerContext: CanvasRenderingContext2D;
  private readonly trailLayer: HTMLCanvasElement;
  private readonly trailContext: CanvasRenderingContext2D;
  private readonly abortController = new AbortController();
  private readonly timers = new Set<number>();
  private resizeObserver: ResizeObserver | null = null;
  private particles: Particle[] = [];
  private stars: AmbientStar[] = [];
  private width = 0;
  private height = 0;
  private dpr = 1;
  private frameId = 0;
  private lastFrameTime = 0;
  private fpsFrameCount = 0;
  private fpsTime = 0;
  private language: Language = "en";
  private palette: PaletteName = "aurora";
  private mode: "attract" | "repel" = "attract";
  private pointer: Point & { active: boolean } = { x: 0, y: 0, active: false };
  private readonly reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  private shiftInverted = false;
  private destroyed = false;
  private failed = false;

  constructor(context: CanvasRenderingContext2D, particleLayer: HTMLCanvasElement, layerContext: CanvasRenderingContext2D, trailLayer: HTMLCanvasElement, trailContext: CanvasRenderingContext2D) {
    this.context = context;
    this.particleLayer = particleLayer;
    this.layerContext = layerContext;
    this.trailLayer = trailLayer;
    this.trailContext = trailContext;
    this.bindEvents();
    this.applyLanguage();
    try {
      this.resize();
    } catch (error) {
      this.handleFailure(error);
    }
    this.resizeObserver = new ResizeObserver(() => {
      try {
        this.resize();
      } catch (error) {
        this.handleFailure(error);
      }
    });
    this.resizeObserver.observe(this.stage);
    if (!this.failed) this.animate(performance.now());
  }

  private bindEvents(): void {
    const signal = this.abortController.signal;
    this.textInput.addEventListener("input", () => this.updateText(), { signal });
    document.querySelectorAll<HTMLButtonElement>("[data-preset]").forEach((button) => {
      button.addEventListener("click", () => {
        const preset = button.dataset.preset;
        if (preset) {
          this.textInput.value = preset;
          this.updateText();
        }
      }, { signal });
    });

    getElement<HTMLButtonElement>("language-toggle").addEventListener("click", () => {
      this.language = this.language === "en" ? "zh" : "en";
      this.applyLanguage();
    }, { signal });

    getElement<HTMLButtonElement>("export-button").addEventListener("click", () => this.exportImage(), { signal });
    getElement<HTMLButtonElement>("attract-button").addEventListener("click", () => this.setMode("attract"), { signal });
    getElement<HTMLButtonElement>("repel-button").addEventListener("click", () => this.setMode("repel"), { signal });
    getElement<HTMLSelectElement>("palette-select").addEventListener("change", (event) => {
      this.palette = (event.currentTarget as HTMLSelectElement).value as PaletteName;
      this.updatePalette();
    }, { signal });

    const rangeSettings: Array<[string, string, string, number]> = [
      ["size-range", "size-value", " px", 1],
      ["speed-range", "speed-value", "×", 1],
      ["gravity-range", "gravity-value", "", 2],
      ["life-range", "life-value", " s", 1]
    ];
    rangeSettings.forEach(([inputId, valueId, suffix, precision]) => {
      const input = getElement<HTMLInputElement>(inputId);
      input.addEventListener("input", () => {
        const value = Number(input.value);
        getElement<HTMLSpanElement>(valueId).innerHTML = `${value.toFixed(precision)}<span>${suffix}</span>`;
      }, { signal });
    });

    getElement<HTMLInputElement>("blur-toggle").addEventListener("change", () => undefined, { signal });
    getElement<HTMLInputElement>("bloom-toggle").addEventListener("change", () => undefined, { signal });
    this.stage.addEventListener("pointermove", (event) => this.updatePointer(event), { signal });
    this.stage.addEventListener("pointerleave", () => { this.pointer.active = false; }, { signal });
    this.stage.addEventListener("pointerdown", (event) => {
      if (event.pointerType !== "mouse") this.updatePointer(event);
    }, { signal });
    window.addEventListener("keydown", (event) => {
      const target = event.target;
      const isEditing = target instanceof HTMLElement && Boolean(target.closest("input, textarea, select, button"));
      if (event.key === "Shift" && !event.repeat && !isEditing) this.shiftInverted = true;
    }, { signal });
    window.addEventListener("keyup", (event) => {
      if (event.key === "Shift") this.shiftInverted = false;
    }, { signal });
    window.addEventListener("blur", () => { this.pointer.active = false; this.shiftInverted = false; }, { signal });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        cancelAnimationFrame(this.frameId);
        this.frameId = 0;
      } else if (!this.destroyed && !this.failed) {
        this.lastFrameTime = 0;
        this.frameId = requestAnimationFrame((time) => this.animate(time));
      }
    }, { signal });
    window.addEventListener("beforeunload", () => this.destroy(), { signal });
  }

  private applyLanguage(): void {
    translateDocument(this.language);
    if (!this.notice.hidden && this.notice.dataset.messageKey) this.showNotice(this.notice.dataset.messageKey);
  }

  private updateText(): void {
    const text = this.textInput.value.trim();
    if (!text) {
      this.showNotice("emptyText");
      return;
    }
    this.clearNotice();
    try {
      this.createTargets(text);
    } catch (error) {
      this.handleFailure(error);
    }
  }

  private resize(): void {
    const bounds = this.stage.getBoundingClientRect();
    const nextWidth = Math.max(1, Math.floor(bounds.width));
    const nextHeight = Math.max(1, Math.floor(bounds.height));
    if (nextWidth === this.width && nextHeight === this.height) return;
    this.width = nextWidth;
    this.height = nextHeight;
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = Math.floor(this.width * this.dpr);
    this.canvas.height = Math.floor(this.height * this.dpr);
    this.particleLayer.width = this.canvas.width;
    this.particleLayer.height = this.canvas.height;
    this.trailLayer.width = this.canvas.width;
    this.trailLayer.height = this.canvas.height;
    this.context.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.layerContext.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.trailContext.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const starCount = clamp(Math.round(this.width * this.height / 3200), 70, 180);
    this.stars = Array.from({ length: starCount }, () => ({
      x: Math.random() * this.width,
      y: Math.random() * this.height,
      radius: 0.3 + Math.random() * 0.8,
      alpha: 0.1 + Math.random() * 0.26,
      phase: Math.random() * Math.PI * 2,
      hue: Math.random()
    }));
    getElement<HTMLElement>("stage-width").textContent = String(this.width).padStart(4, "0");
    getElement<HTMLElement>("stage-height").textContent = String(this.height).padStart(4, "0");
    if (this.textInput.value.trim()) this.createTargets(this.textInput.value.trim());
  }

  private createTargets(text: string): void {
    if (this.width < 2 || this.height < 2) return;
    const scale = 1.5;
    const mask = document.createElement("canvas");
    mask.width = Math.ceil(this.width * scale);
    mask.height = Math.ceil(this.height * scale);
    const maskContext = mask.getContext("2d", { willReadFrequently: true });
    if (!maskContext) throw new Error("Canvas 2D is unavailable.");

    const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    if (lines.length === 0) return;
    const longestLine = Math.max(...lines.map((line) => line.length));
    let fontSize = Math.min(this.height * 0.56 / lines.length, this.width * 0.78 / Math.max(1, longestLine * 0.64));
    fontSize = clamp(fontSize, 18, Math.min(220, this.height * 0.7));
    maskContext.scale(scale, scale);
    maskContext.fillStyle = "#ffffff";
    maskContext.textAlign = "center";
    maskContext.textBaseline = "middle";
    maskContext.lineJoin = "round";
    maskContext.font = `800 ${fontSize}px Inter, ui-sans-serif, system-ui, Arial, sans-serif`;
    const maxTextWidth = this.width * 0.84;
    const widest = Math.max(...lines.map((line) => maskContext.measureText(line).width));
    if (widest > maxTextWidth) {
      fontSize *= maxTextWidth / widest;
      maskContext.font = `800 ${fontSize}px Inter, ui-sans-serif, system-ui, Arial, sans-serif`;
    }
    const lineHeight = fontSize * 1.16;
    const startY = (this.height - lineHeight * (lines.length - 1)) / 2;
    lines.forEach((line, index) => maskContext.fillText(line, this.width / 2, startY + index * lineHeight, maxTextWidth));

    const image = maskContext.getImageData(0, 0, mask.width, mask.height);
    const stride = Math.max(4, Math.floor(fontSize * scale / 33));
    const candidates: Point[] = [];
    for (let y = 0; y < mask.height; y += stride) {
      for (let x = 0; x < mask.width; x += stride) {
        const pixelIndex = (y * mask.width + x) * 4;
        if (image.data[pixelIndex + 3] > 96) candidates.push({ x: x / scale, y: y / scale });
      }
    }

    const maxParticles = 14000;
    const sampleStride = Math.max(1, Math.ceil(candidates.length / maxParticles));
    const targets = candidates.filter((_, index) => index % sampleStride === 0);
    const lifeSetting = Number(getElement<HTMLInputElement>("life-range").value);
    const nextParticles: Particle[] = [];
    const oldParticles = this.particles;
    targets.forEach((target, index) => {
      const particle = oldParticles[index];
      if (particle) {
        particle.targetX = target.x;
        particle.targetY = target.y;
        nextParticles.push(particle);
      } else {
        nextParticles.push({
          x: Math.random() * this.width,
          y: Math.random() * this.height,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          targetX: target.x,
          targetY: target.y,
          radius: 0.42 + Math.random() * 1.02,
          color: palettes[this.palette][0],
          age: Math.random() * lifeSetting,
          life: 0.78 + Math.random() * 0.44,
          phase: Math.random() * Math.PI * 2,
          sparkle: Math.random() < 0.045
        });
      }
    });
    this.particles = nextParticles;
    this.updatePalette();
    getElement<HTMLElement>("particle-count").textContent = targets.length.toLocaleString(this.language === "zh" ? "zh-CN" : "en-US");
  }

  private updatePalette(): void {
    const colors = palettes[this.palette];
    this.particles.forEach((particle) => {
      const ratio = clamp(particle.targetX / Math.max(this.width, 1), 0, 0.9999);
      particle.color = interpolatePalette(colors, ratio);
    });
    const swatch = getElement<HTMLElement>("palette-swatch");
    swatch.className = `palette-swatch ${this.palette}`;
  }

  private updatePointer(event: PointerEvent): void {
    const bounds = this.stage.getBoundingClientRect();
    this.pointer.x = event.clientX - bounds.left;
    this.pointer.y = event.clientY - bounds.top;
    this.pointer.active = true;
  }

  private setMode(mode: "attract" | "repel"): void {
    this.mode = mode;
    const attractButton = getElement<HTMLButtonElement>("attract-button");
    const repelButton = getElement<HTMLButtonElement>("repel-button");
    attractButton.classList.toggle("is-active", mode === "attract");
    repelButton.classList.toggle("is-active", mode === "repel");
    attractButton.setAttribute("aria-pressed", String(mode === "attract"));
    repelButton.setAttribute("aria-pressed", String(mode === "repel"));
  }

  private animate(time: number): void {
    if (this.destroyed || this.failed || document.hidden) return;
    try {
      const delta = this.lastFrameTime === 0 ? 0.016 : Math.min(0.04, Math.max(0.001, (time - this.lastFrameTime) / 1000));
      this.lastFrameTime = time;
      this.render(delta, time);
      this.updateFps(time);
      this.frameId = requestAnimationFrame((nextTime) => this.animate(nextTime));
    } catch (error) {
      console.error("Particle canvas render failed", error);
      this.failed = true;
      this.handleFailure(error);
    }
  }

  private render(delta: number, time: number): void {
    const context = this.layerContext;
    context.clearRect(0, 0, this.width, this.height);
    const size = Number(getElement<HTMLInputElement>("size-range").value);
    const speed = Number(getElement<HTMLInputElement>("speed-range").value) * (this.reducedMotion ? 0.65 : 1);
    const gravity = Number(getElement<HTMLInputElement>("gravity-range").value);
    const life = Number(getElement<HTMLInputElement>("life-range").value);
    const blurEnabled = getElement<HTMLInputElement>("blur-toggle").checked;
    const pointerRadius = Math.min(260, Math.max(100, this.width * 0.22));
    const effectiveMode = this.shiftInverted ? (this.mode === "attract" ? "repel" : "attract") : this.mode;

    context.globalCompositeOperation = "lighter";
    this.stars.forEach((star) => {
      const shimmer = 0.68 + Math.sin(time * 0.0008 + star.phase) * 0.32;
      context.globalAlpha = star.alpha * shimmer;
      context.fillStyle = interpolatePalette(palettes[this.palette], star.hue);
      context.beginPath();
      context.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
      context.fill();
    });
    context.globalCompositeOperation = "source-over";

    for (const particle of this.particles) {
      const dx = particle.targetX - particle.x;
      const dy = particle.targetY - particle.y;
      particle.vx += dx * 0.028 * speed * delta * 60;
      particle.vy += (dy * 0.028 * speed + gravity * 0.08) * delta * 60;
      const breeze = Math.sin(time * 0.0007 + particle.phase + particle.targetY * 0.012) * 0.012;
      particle.vx += Math.cos(particle.phase) * breeze * delta * 60;
      particle.vy += Math.sin(particle.phase) * breeze * delta * 60;
      particle.vx *= Math.pow(0.89, delta * 60);
      particle.vy *= Math.pow(0.89, delta * 60);

      if (this.pointer.active) {
        const pointerDx = particle.x - this.pointer.x;
        const pointerDy = particle.y - this.pointer.y;
        const distance = Math.max(1, Math.hypot(pointerDx, pointerDy));
        if (distance < pointerRadius) {
          const falloff = (1 - distance / pointerRadius) ** 2;
          const direction = effectiveMode === "attract" ? -1 : 1;
          const force = falloff * speed * (effectiveMode === "attract" ? 1.7 : 2.5) * delta * 60;
          const swirl = Math.sin(time * 0.0014 + particle.phase) * force * 0.16;
          const unitX = pointerDx / distance;
          const unitY = pointerDy / distance;
          particle.vx += unitX * force * direction - unitY * swirl;
          particle.vy += unitY * force * direction + unitX * swirl;
        }
      }

      particle.x += particle.vx * delta * 60;
      particle.y += particle.vy * delta * 60;
      particle.age += delta;
      const particleLife = life * particle.life;
      if (particle.age > particleLife) {
        particle.age = 0;
        particle.x = particle.targetX + (Math.random() - 0.5) * 30;
        particle.y = particle.targetY + (Math.random() - 0.5) * 30;
        particle.vx *= 0.35;
        particle.vy *= 0.35;
      }

      const fadeIn = clamp(particle.age / 0.55, 0, 1);
      const fadeOut = clamp((particleLife - particle.age) / 0.85, 0, 1);
      const pulse = this.reducedMotion ? 1 : 0.78 + Math.sin(time * 0.0012 + particle.phase) * 0.22;
      const alpha = Math.min(fadeIn, fadeOut) * pulse;
      const radius = size * particle.radius;
      context.globalAlpha = alpha * (blurEnabled ? 0.34 : 0.2);
      context.fillStyle = particle.color;
      if (blurEnabled) {
        context.lineWidth = Math.max(0.5, radius * 0.85);
        context.beginPath();
        context.moveTo(particle.x - particle.vx * 0.1, particle.y - particle.vy * 0.1);
        context.lineTo(particle.x, particle.y);
        context.strokeStyle = particle.color;
        context.stroke();
      }
      context.globalAlpha = alpha;
      context.beginPath();
      context.arc(particle.x, particle.y, radius, 0, Math.PI * 2);
      context.fill();
      context.globalAlpha = alpha * 0.56;
      context.fillStyle = "#f4fff9";
      context.beginPath();
      context.arc(particle.x, particle.y, Math.max(0.28, radius * 0.3), 0, Math.PI * 2);
      context.fill();
      if (particle.sparkle) {
        const gleam = radius * (2.2 + Math.sin(time * 0.002 + particle.phase) * 0.7);
        context.globalAlpha = alpha * (0.3 + Math.sin(time * 0.0015 + particle.phase) * 0.2);
        context.strokeStyle = particle.color;
        context.lineWidth = Math.max(0.35, radius * 0.22);
        context.beginPath();
        context.moveTo(particle.x - gleam, particle.y);
        context.lineTo(particle.x + gleam, particle.y);
        context.moveTo(particle.x, particle.y - gleam);
        context.lineTo(particle.x, particle.y + gleam);
        context.stroke();
      }
    }
    context.globalAlpha = 1;
    context.globalCompositeOperation = "source-over";

    const trails = this.trailContext;
    trails.globalCompositeOperation = "destination-out";
    trails.fillStyle = "rgba(0, 0, 0, 0.075)";
    trails.fillRect(0, 0, this.width, this.height);
    trails.globalCompositeOperation = "lighter";
    trails.globalAlpha = 0.3;
    trails.drawImage(this.particleLayer, 0, 0, this.width, this.height);
    trails.globalAlpha = 1;
    trails.globalCompositeOperation = "source-over";

    const main = this.context;
    main.clearRect(0, 0, this.width, this.height);
    main.globalCompositeOperation = "screen";
    if (this.pointer.active) {
      const radius = pointerRadius * 1.7;
      const hue = effectiveMode === "attract" ? palettes[this.palette][0] : palettes[this.palette][palettes[this.palette].length - 1];
      const aura = main.createRadialGradient(this.pointer.x, this.pointer.y, 0, this.pointer.x, this.pointer.y, radius);
      aura.addColorStop(0, `${hue}30`);
      aura.addColorStop(0.42, `${hue}16`);
      aura.addColorStop(1, `${hue}00`);
      main.fillStyle = aura;
      main.fillRect(this.pointer.x - radius, this.pointer.y - radius, radius * 2, radius * 2);
    }
    if (getElement<HTMLInputElement>("bloom-toggle").checked) {
      main.save();
      main.globalAlpha = 0.32;
      main.filter = "blur(18px)";
      main.drawImage(this.trailLayer, 0, 0, this.width, this.height);
      main.globalAlpha = 0.62;
      main.filter = `blur(${Math.max(4, size * 4)}px)`;
      main.drawImage(this.particleLayer, 0, 0, this.width, this.height);
      main.restore();
    }
    main.globalAlpha = 0.72;
    main.drawImage(this.trailLayer, 0, 0, this.width, this.height);
    main.globalAlpha = 1;
    main.drawImage(this.particleLayer, 0, 0, this.width, this.height);
    main.globalCompositeOperation = "source-over";
  }

  private updateFps(time: number): void {
    this.fpsFrameCount += 1;
    if (this.fpsTime === 0) this.fpsTime = time;
    if (time - this.fpsTime >= 600) {
      const fps = Math.round(this.fpsFrameCount * 1000 / (time - this.fpsTime));
      getElement<HTMLElement>("fps-value").textContent = String(clamp(fps, 1, 120));
      this.fpsFrameCount = 0;
      this.fpsTime = time;
    }
  }

  private async exportImage(): Promise<void> {
    try {
      if (!this.particles.length) {
        this.showNotice("emptyText");
        return;
      }
      const scale = Math.min(4, 16384 / Math.max(this.width, this.height));
      const output = document.createElement("canvas");
      output.width = Math.round(this.width * scale);
      output.height = Math.round(this.height * scale);
      const outputContext = output.getContext("2d");
      if (!outputContext) throw new Error("Could not create export canvas.");
      outputContext.scale(scale, scale);

      const background = outputContext.createLinearGradient(0, 0, this.width, this.height);
      background.addColorStop(0, "#111625");
      background.addColorStop(0.52, "#0a0e17");
      background.addColorStop(1, "#10111a");
      outputContext.fillStyle = background;
      outputContext.fillRect(0, 0, this.width, this.height);
      const halo = outputContext.createRadialGradient(this.width * 0.5, this.height * 0.48, 0, this.width * 0.5, this.height * 0.48, this.width * 0.54);
      halo.addColorStop(0, "rgba(103, 124, 183, 0.13)");
      halo.addColorStop(1, "rgba(12, 15, 25, 0)");
      outputContext.fillStyle = halo;
      outputContext.fillRect(0, 0, this.width, this.height);
      outputContext.strokeStyle = "rgba(158, 177, 213, 0.055)";
      outputContext.lineWidth = 1;
      for (let x = 0; x < this.width; x += 32) {
        outputContext.beginPath();
        outputContext.moveTo(x, 0);
        outputContext.lineTo(x, this.height);
        outputContext.stroke();
      }
      for (let y = 0; y < this.height; y += 32) {
        outputContext.beginPath();
        outputContext.moveTo(0, y);
        outputContext.lineTo(this.width, y);
        outputContext.stroke();
      }

      outputContext.globalCompositeOperation = "screen";
      if (getElement<HTMLInputElement>("bloom-toggle").checked) {
        outputContext.save();
        outputContext.globalAlpha = 0.3;
        outputContext.filter = "blur(22px)";
        outputContext.drawImage(this.trailLayer, 0, 0, this.width, this.height);
        outputContext.globalAlpha = 0.58;
        outputContext.filter = `blur(${Math.max(5, Number(getElement<HTMLInputElement>("size-range").value) * 4)}px)`;
        outputContext.drawImage(this.particleLayer, 0, 0, this.width, this.height);
        outputContext.restore();
      }
      outputContext.globalAlpha = 0.72;
      outputContext.drawImage(this.trailLayer, 0, 0, this.width, this.height);
      outputContext.globalAlpha = 1;
      this.drawExportParticles(outputContext);
      outputContext.globalCompositeOperation = "source-over";

      const blob = await new Promise<Blob | null>((resolve) => output.toBlob(resolve, "image/png"));
      if (this.destroyed) return;
      if (!blob) throw new Error("Canvas image encoding failed.");
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `forma-particles-${new Date().toISOString().slice(0, 10)}.png`;
      anchor.click();
      const timer = window.setTimeout(() => {
        URL.revokeObjectURL(url);
        this.timers.delete(timer);
      }, 2000);
      this.timers.add(timer);
      this.showNotice("exportSuccess");
    } catch (error) {
      console.error("Particle image export failed", error);
      if (!this.destroyed) this.showNotice("exportError");
    }
  }

  private drawExportParticles(context: CanvasRenderingContext2D): void {
    const size = Number(getElement<HTMLInputElement>("size-range").value);
    const blurEnabled = getElement<HTMLInputElement>("blur-toggle").checked;
    const life = Number(getElement<HTMLInputElement>("life-range").value);
    for (const particle of this.particles) {
      const particleLife = life * particle.life;
      const alpha = Math.min(clamp(particle.age / 0.55, 0, 1), clamp((particleLife - particle.age) / 0.85, 0, 1));
      const radius = size * particle.radius;
      context.globalAlpha = alpha * (blurEnabled ? 0.32 : 0.2);
      context.fillStyle = particle.color;
      if (blurEnabled) {
        context.lineWidth = Math.max(0.6, radius * 0.85);
        context.beginPath();
        context.moveTo(particle.x - particle.vx * 0.1, particle.y - particle.vy * 0.1);
        context.lineTo(particle.x, particle.y);
        context.strokeStyle = particle.color;
        context.stroke();
      }
      context.globalAlpha = alpha;
      context.beginPath();
      context.arc(particle.x, particle.y, radius, 0, Math.PI * 2);
      context.fill();
      context.globalAlpha = alpha * 0.56;
      context.fillStyle = "#f4fff9";
      context.beginPath();
      context.arc(particle.x, particle.y, Math.max(0.28, radius * 0.3), 0, Math.PI * 2);
      context.fill();
      if (particle.sparkle) {
        const gleam = radius * 2.5;
        context.globalAlpha = alpha * 0.52;
        context.strokeStyle = particle.color;
        context.lineWidth = Math.max(0.4, radius * 0.22);
        context.beginPath();
        context.moveTo(particle.x - gleam, particle.y);
        context.lineTo(particle.x + gleam, particle.y);
        context.moveTo(particle.x, particle.y - gleam);
        context.lineTo(particle.x, particle.y + gleam);
        context.stroke();
      }
    }
    context.globalAlpha = 1;
  }

  private showNotice(key: string): void {
    this.notice.dataset.messageKey = key;
    this.notice.textContent = translations[this.language][key] ?? key;
    this.notice.hidden = false;
  }

  private clearNotice(): void {
    this.notice.hidden = true;
    delete this.notice.dataset.messageKey;
    this.notice.textContent = "";
  }

  private handleFailure(error: unknown): void {
    console.error("Particle field failed", error);
    this.failed = true;
    cancelAnimationFrame(this.frameId);
    this.frameId = 0;
    this.showNotice("renderError");
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.abortController.abort();
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    cancelAnimationFrame(this.frameId);
    this.frameId = 0;
    this.timers.forEach((timer) => window.clearTimeout(timer));
    this.timers.clear();
    this.particles.length = 0;
    this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.layerContext.clearRect(0, 0, this.particleLayer.width, this.particleLayer.height);
    this.trailContext.clearRect(0, 0, this.trailLayer.width, this.trailLayer.height);
    this.particleLayer.width = 0;
    this.particleLayer.height = 0;
    this.trailLayer.width = 0;
    this.trailLayer.height = 0;
  }
}

try {
  const canvas = getElement<HTMLCanvasElement>("particle-canvas");
  const context = canvas.getContext("2d", { alpha: true });
  const layer = document.createElement("canvas");
  const layerContext = layer.getContext("2d", { alpha: true });
  const trailLayer = document.createElement("canvas");
  const trailContext = trailLayer.getContext("2d", { alpha: true });
  if (!context || !layerContext || !trailContext) throw new Error("Canvas 2D is unavailable.");
  new ParticleTextApp(context, layer, layerContext, trailLayer, trailContext);
} catch (error) {
  console.error("Particle text studio could not start", error);
  let fallbackLanguage: Language = "en";
  const languageButton = document.getElementById("language-toggle");
  languageButton?.addEventListener("click", () => {
    fallbackLanguage = fallbackLanguage === "en" ? "zh" : "en";
    translateDocument(fallbackLanguage);
    const fallbackNotice = document.getElementById("notice");
    const messageKey = fallbackNotice?.dataset.messageKey;
    if (fallbackNotice && messageKey) fallbackNotice.textContent = translations[fallbackLanguage][messageKey] ?? messageKey;
  });
  translateDocument(fallbackLanguage);
  const notice = document.getElementById("notice");
  if (notice) {
    notice.dataset.messageKey = "canvasError";
    notice.textContent = translations[fallbackLanguage].canvasError;
    notice.hidden = false;
  }
}
